package com.example.MovieApis.movie.Repository;




import org.springframework.data.repository.CrudRepository;


import com.example.MovieApis.movie.model.UserInfo;


public interface UserInfoRepository extends CrudRepository<UserInfo, Long> {


}
